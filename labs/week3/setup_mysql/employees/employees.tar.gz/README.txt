######## README FILE ###########

1. extract tarball to stage employees database
	tar -zxvf employees.tar.gz

2. execute ./1_create_database_employees_tables.sh

